package com.graded.employeeManagement.User;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AppUserRepo extends JpaRepository<AppUser, Integer> {
	
	//create custom method using JPA
		Optional<AppUser> findByName(String name);
		
		//function name must start with "findBy" -selection query with condition\
		//column name -'required name'
		//in our care name 
		
		//find query only give the one data
		//select * from table where name="required name";
		//only one output
		
		// but we get multiple data so using option
}
