package com.graded.employeeManagement.model;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;


@Service
public class EmployeeService {

	@Autowired
	EmployeeRepo repo;
	
	public void add(Employee emp) {
		repo.save(emp);
	}
	public void update(Employee emp) {
		repo.save(emp);
	}
	public void delete(Employee emp) {
		repo.delete(emp);
	}
	public List<Employee> getAll(){
		return repo.findAll();
	}
	public Employee getById(int id) {
		if(repo.findById(id).isEmpty()) {
			return null;
		}else {
			return repo.findById(id).get();
		}
	}
	public List<Employee> getBySort(String columnName, Direction direction) {
		return repo.findAll(Sort.by(direction, columnName));
	}

	public List<Employee> getByEmpName(String searchkey) {

		// create dummy 
		Employee dummy = new Employee();
		dummy.setEmpName(searchkey);

		// using WHERE clause to check contains or what
		ExampleMatcher em = ExampleMatcher.matching()
				.withMatcher("EmpName", ExampleMatcher.GenericPropertyMatchers.contains())
				.withIgnorePaths("id", "EmpAge", "Department");

		// here we Combining dummy and WHERE
		Example<Employee> ex = Example.of(dummy, em);
		return repo.findAll(ex);
	}
	
}
