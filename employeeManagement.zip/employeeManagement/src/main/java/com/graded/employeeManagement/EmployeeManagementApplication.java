package com.graded.employeeManagement;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.graded.employeeManagement.User.AppUser;
import com.graded.employeeManagement.User.AppUserService;


@SpringBootApplication
public class EmployeeManagementApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementApplication.class, args);
	}
	@Autowired
	AppUserService appService;
		
	@Override
	public void run(String... args) throws Exception {
		Set<String> authAdmin=new HashSet<>();
		authAdmin.add("Admin");
		
		Set<String> authUser=new HashSet<>();
		authUser.add("User");
		
		PasswordEncoder en=new BCryptPasswordEncoder();
		
		AppUser appAdmin=new AppUser(1, "admin", "admin", en.encode("admin"),authAdmin);
		appService.add(appAdmin);
		 
		
		AppUser appUser=new AppUser(2, "user", "user", en.encode("user"), authUser);
		appService.add(appUser);	
			
	}	

}
